#! /bin/bash

goahead  /var/www/goahead