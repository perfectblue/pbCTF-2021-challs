module EmailHelper
end
